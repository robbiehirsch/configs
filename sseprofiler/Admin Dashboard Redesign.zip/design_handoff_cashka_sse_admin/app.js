// CashKA SSE Admin — demo-only glue for the static design reference.
// In production, htmx handles all of this via server-rendered fragments:
//   - view switching:   hx-get="/admin/topology" hx-target="#view" hx-push-url
//   - inspector pivots: hx-get="/admin/inspect/<type>/<id>" hx-target="#inspector"
//   - live events:      hx-ext="sse" sse-connect="/admin/events/stream"
// This file only makes the flat demo clickable (tab toggling, row selection)
// and shows where the real wiring goes. Delete or replace it in production.

document.addEventListener('DOMContentLoaded', function () {
  var view = document.getElementById('view');
  var streamHTML = null;

  // Demo tab switching (production: htmx swaps #view; keep the .is-active toggle).
  document.querySelectorAll('.app-header .seg-opt[data-view]').forEach(function (btn) {
    btn.addEventListener('click', function (ev) {
      ev.preventDefault();
      document.querySelectorAll('.app-header .seg-opt[data-view]').forEach(function (b) { b.classList.remove('is-active'); });
      btn.classList.add('is-active');
      var which = btn.getAttribute('data-view');
      if (streamHTML === null) streamHTML = document.getElementById('stream').outerHTML;
      var stream = document.getElementById('stream');
      var mounted = view.querySelector('.topo-wrap, .trace');
      if (mounted) mounted.remove();
      if (which === 'topology') {
        if (stream) stream.style.display = 'none';
        view.insertAdjacentHTML('afterbegin', document.getElementById('tpl-topology').innerHTML);
      } else if (stream) {
        stream.style.display = '';
      }
    });
  });

  // Demo: open the trace view from the inspector's "Trace delivery" pivot.
  document.addEventListener('click', function (ev) {
    var a = ev.target.closest('[hx-get^="/admin/trace/"]');
    if (!a) return;
    ev.preventDefault();
    var stream = document.getElementById('stream');
    if (stream) stream.style.display = 'none';
    var mounted = view.querySelector('.topo-wrap, .trace');
    if (mounted) mounted.remove();
    view.insertAdjacentHTML('afterbegin', document.getElementById('tpl-trace').innerHTML);
  });
  // Demo: trace "← Live Stream" back link.
  document.addEventListener('click', function (ev) {
    var a = ev.target.closest('[hx-get="/admin/stream"]');
    if (!a) return;
    ev.preventDefault();
    var mounted = view.querySelector('.trace, .topo-wrap');
    if (mounted) mounted.remove();
    var stream = document.getElementById('stream');
    if (stream) stream.style.display = '';
  });

  // Demo row selection highlight (production: server marks .is-selected,
  // or keep this optimistic toggle alongside the htmx request).
  document.addEventListener('click', function (ev) {
    var row = ev.target.closest('.stream-row');
    if (!row) return;
    document.querySelectorAll('.stream-row.is-selected').forEach(function (r) { r.classList.remove('is-selected'); });
    row.classList.add('is-selected');
  });

  // Demo pause toggle (production: also close/reopen the EventSource or
  // set a flag the sse-swap handler checks).
  var paused = false;
  document.getElementById('pause-btn').addEventListener('click', function () {
    paused = !paused;
    this.textContent = paused ? 'Resume stream' : 'Pause stream';
    var pill = document.querySelector('.live-pill');
    pill.classList.toggle('is-paused', paused);
    pill.lastChild.textContent = paused ? 'paused' : 'live';
  });
});

/* Production SSE notes (htmx sse extension already wired in index.html):
   <div id="stream-rows" hx-ext="sse" sse-connect="/admin/events/stream"
        sse-swap="admin-event" hx-swap="afterbegin">
   The server emits, per admin event:
     event: admin-event
     data: <div class="stream-row" hx-get="/admin/inspect/message/...">...</div>
   Cap the list client-side (e.g. htmx:sseMessage listener trimming to 200 rows).
   Stat strip: either sse-swap="stats" into #stats, or hx-get poll every 5s. */
