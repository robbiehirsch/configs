# Handoff: CashKA SSE Admin dashboard redesign

## Overview
Admin dashboard for a service that consumes Kafka topics and fans messages out to
end users over SSE, keyed by firmID (auth header carries userId + firmId; a user can
hold multiple concurrent SSE sessions). The redesign is built around one idea:
**everything is a pivot** — topic -> subscribers + publishes, message -> recipients,
user -> subscriptions + sessions + history — without ever losing the page.

Three views share one persistent right-hand inspector rail:

1. **Live Stream** (default) — a unified, newest-first event feed (KAFKA, FANOUT,
   CONN, DROP, HB). Every id in a row is a link that loads that entity into the
   inspector. Filter chips + global search + pause.
2. **CashKA Topology** — the fan-out drawn as a map: topics -> firms -> SSE client
   pool, edge width = volume. Clicking a node inspects it in the same rail.
3. **Trace** (per selected message) — receive -> fan-out -> delivery stage cards,
   then a per-recipient table with delivered/missed status and latency.

## About the design files
The files in this bundle are **design references created in HTML**. index.html +
styles.css + app.js open directly in a browser and show the intended look and
behavior with static sample data. The task is to implement this design in the
target stack — **vanilla HTML/CSS/JS + htmx, server-rendered fragments** — using
these files as the source of truth for markup structure, class names, and styling.
styles.css is production-ready as-is (plain CSS, no build step) and is intended to
be adopted directly. app.js is demo glue only; htmx replaces it.

## Fidelity
**High-fidelity.** Colors, typography, spacing, radii, and states are final
(Nocturne design system). Recreate pixel-perfectly. All data shown is fake but
shaped like production (topic names, cash ids, firm ids, session guids).

## Architecture (htmx)
The app is one shell page + server-rendered fragments. Two swap targets:

- \#view — the left pane (stream / topology / trace views)
- \#inspector — the right rail (message / user / firm / topic fragments)

Suggested endpoints (rename to fit your routes):

    GET  /admin/ui                                 full shell (index.html structure)
    GET  /admin/stream                             stream view fragment -> #view
    GET  /admin/stream/rows?filter=&q=             row list fragment -> #stream-rows
    GET  /admin/topology                           topology view fragment -> #view
    GET  /admin/trace/{messageId}                  trace view fragment -> #view
    GET  /admin/trace/{messageId}/rows?missed=1    recipient rows -> #trace-rows
    GET  /admin/inspect/message/{topic:part:offset} -> #inspector
    GET  /admin/inspect/user/{userId}              -> #inspector
    GET  /admin/inspect/firm/{firmId}              -> #inspector
    GET  /admin/inspect/topic/{topicId}            -> #inspector
    POST /admin/topics/{id}/pause                  toggles; returns topic inspector
    POST /admin/firms/{id}/mute                    toggles; returns firm inspector
    POST /admin/sessions/{id}/disconnect           returns updated row (or empty)
    POST /admin/users/{id}/disconnect-all          returns user inspector
    GET  /admin/events/stream                      SSE: event "admin-event", data = one
                                                   .stream-row fragment (see app.js notes)
    GET  /admin/export/events|trace/{id}|topic/{id}  file downloads

Conventions used in the reference markup:
- Pivot links: hx-get="/admin/inspect/..." hx-target="#inspector" (row links must
  stop bubbling so the row's own hx-get does not also fire — hx-on:click="event.stopPropagation()").
- View changes push URLs (hx-push-url="true") so topic/message/user views deep-link.
- Live feed: htmx SSE extension on #stream-rows, hx-swap="afterbegin", server sends
  ready-made .stream-row fragments. Trim the DOM list to ~200 rows client-side.
- Destructive actions use hx-confirm (see session disconnect in inspector-user.html).

## Screens / views

### Shell (index.html)
- .app: 100vh column; header, fading .hr, then .layout grid "1fr 400px".
- Header (.app-header): flex, wraps at narrow widths; gap 8.4px/11.2px.
  Order: brand, view tabs (.seg), search (.input.search, flex 1 1 200px,
  max 360px, min 140px), time-range .seg, .stat-strip (margin-left auto),
  Pause + Export buttons (.btn-secondary.btn-sm), live pill (.tag-outline
  with pulsing .live-dot). Both .seg controls are flex:none + nowrap —
  the search absorbs shrink. Stats: 12px, values weight 500.
- Right rail (.pane-inspector): 400px, own scroll, background is a 55/45 mix
  of surface over bg; bottom-pinned .actions row (buttons flex:1).

### Live Stream
- .chip-row: filter chips are .tag (active = .tag-accent, rest .tag-outline),
  count label right-aligned 11px at 45% text.
- .stream-row grid: 112px (time) / 74px (type tag) / 1fr (description,
  ellipsized) / auto (meta). Padding 6px 8px, radius 6px, negative 8px
  side margins so the hover pill spans the pane.
- Row hover: 5% text-mix wash. Selected: .is-selected, 9% accent wash.
- Type tags: KAFKA=.tag-accent, FANOUT=.tag-outline, CONN/DROP/HB=.tag-neutral,
  all 10px. Meta 11px 60% text; failures use .is-warn (--color-warn).
- Description: plain text at full color; ids are accent <a> links; topic ids
  and session guids in --font-mono.

### Inspector fragments (partials/)
- Kicker (.kicker, 10px uppercase accent) names the entity type; title is
  mono 14.5px for ids (.insp-title) or Inter 500 17px for names (.insp-title-lg).
- Message: .json-block payload (11.5px mono, keys tinted --color-accent-300,
  values 75% text on bg with 10% border); .pivot-list rows (13px accent,
  context in 60% text, arrow pushed right) separated by fading .hr; delivery
  list (.list-row): user link, mono session, .status-ok "(check) delivered" in
  accent-300 / .status-miss in --color-warn, latency mono 11px right-aligned
  44px column. Actions: Export JSON (.btn-primary), Copy message id.
- User: sessions with per-session ghost Disconnect buttons (hx-confirm),
  subscriptions as mono topic links, recent activity rows, Disconnect all.
- Firm: stats line, subscribed topics, connected (named) users + "+ N more",
  actions: Filter stream to firm (primary), Mute firm.
- Topic: rate + partition tags, recent publishes (mono part:offset links ->
  message inspector), subscribers by firm (firmID in accent-100 mono),
  actions: Pause/Resume topic (primary), Export log.

### CashKA Topology
- Fixed 980x540 canvas (.topo-canvas) inside a scrollable wrapper; SVG edge
  layer behind absolutely-positioned node cards.
- Columns: topics left:28px width:252px, rows y=62+118*i; firms left:440px
  width:228px, rows y=54+82*j; client pool left:770px top:212px width:186px.
- Edges: cubic beziers (control points +-85px), stroke gradients that fade at
  the ends (Nocturne rule treatment): url(#edge-dim) 13% accent for idle,
  url(#edge-hot) 85% accent for edges touching the selected node. Width 2-8px
  proportional to hourly volume; selected = 3px hot.
- Nodes: .topo-node (surface bg, 12% text outline, radius-md). Selected:
  .is-active -> accent outline + --glow-accent. Paused/muted: opacity .65 +
  .tag-neutral "paused". Names mono 12.5px; selected name accent-100.
- Node click = same inspector pivots (hx-get inspect fragments).

### Trace
- Header row: "<- Live Stream" back link, TRACE kicker, mono message id + cash
  id, Export trace right-aligned.
- .trace-stages grid "1fr 36px 1.1fr 36px 1fr": three .card stage tiles with
  kickers "1 - Kafka receive / 2 - Fan-out by firmID / 3 - SSE delivery",
  joined by accent arrow SVGs at 70% opacity.
- Recipients table: grid "1fr 110px 110px 1.3fr 70px"; uppercase 11px header
  at 55% text; rows 12.5px; missed rows get .is-miss (9% warn wash) and the
  status cell explains why ("missed - session timed out 20:49:38").
- "all / missed only" filter chips swap #trace-rows.

## Interactions & behavior
- Any id anywhere -> inspector swap. Row click -> row's primary entity
  (kafka/fanout rows -> message; conn/drop rows -> user). HB rows inert.
- Live pill: pulsing accent dot (2s opacity keyframe); paused state swaps to
  neutral dot + "paused" label.
- Pause stream stops SSE appends (keep the connection; buffer or drop).
- Hovers: rows 5% wash; buttons per Nocturne (primary/ghost accent tints,
  secondary 7% text wash); links accent -> accent-300 + underline.
- Focus: 2px accent outline, offset 2px (already in styles.css). Never the
  browser default ring.
- Copy message id: clipboard write + label flips to "Copied".
- Search: 300ms debounced input -> row fragment swap.
- Responsive: header wraps; below ~1100px consider collapsing the inspector
  to an overlay — not designed, use judgment.

## State
Server-driven (htmx): the only client state is what is in the DOM + URL.
- URL carries view + selected entity (hx-push-url) for deep links.
- Selected entity: server renders .is-selected on the matching row (or keep
  the optimistic classList toggle from app.js).
- Topic paused / firm muted live server-side; toggling returns the refreshed
  inspector fragment (and topology fragment if visible).

## Design tokens (Nocturne)
Colors: bg #161826, surface #232532, text #e9e9ed, accent #9184d9,
divider = 16% text. Accent ramp 100-900: #f5f4ff #e7e5fe #d2cefd #b5abfc
#968ae0 #796cbf #5d5294 #423a6a #2b2741. Neutral ramp 100-900: #f3f5fe
#e4e7f5 #cfd3e5 #b2b6ca #9397ab #75798c #595d6c #3f424d #292b31.
Warn (only non-Nocturne color; delivery failures only): oklch(0.72 0.12 25).
Muted text steps: 75/60/55/45/40% mixes of text into transparent.
Type: Inter 400 (body 14px), headings Inter 500 (never bolder); mono stack
ui-monospace/Menlo for ids, offsets, sessions, times, JSON.
Spacing: 2.8 / 5.6 / 8.4 / 11.2 / 16.8 / 22.4 px (--space-1..8).
Radii: 4 / 8 / 14 px. Rows 6px.
Shadows: hairline+ambient (--shadow-sm/md/lg); selected-node glow
0 0 24px 22%-accent. Rules fade to transparent over 48px each side (.hr).
Rules of the system: accent is a line/glow, never a flood; primary buttons
are accent OUTLINES, never fills; no pure black/white; hierarchy via size
and space, not weight.

## Assets
None. No images or icon fonts; the only graphics are inline SVGs (topology
edges, trace arrows) included in the reference markup. If icons are wanted
later, the design system prescribes Phosphor (phosphoricons.com).

## Files
- styles.css — production-ready component sheet (adopt directly)
- index.html — shell + Live Stream view + message inspector, htmx attributes
  wired as documentation; topology and trace views inlined as <template>s
- app.js — demo-only glue (replace with htmx server round-trips)
- partials/stream-rows.html — example rows fragment / SSE event payloads
- partials/inspector-message.html, inspector-user.html, inspector-firm.html,
  inspector-topic.html — the four #inspector fragments
- partials/trace.html — trace view fragment for #view
- partials/topology.html — topology view fragment for #view
- The interactive prototype lives in the design project as
  "CashKA SSE Admin.dc.html" (React-based; reference for behavior only).
