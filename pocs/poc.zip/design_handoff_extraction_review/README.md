# Handoff: Automated Client Data Extraction & Review

## Overview
Clients send transaction/booking instructions in many inconsistent formats (email, CSV, proprietary XML variants, PDFs, scanned images). Today staff **retype** every field into the internal "Create New Entry" form — slow and error-prone. This feature ingests a client file, **auto-extracts and maps** its values into the entry form, and gives the user a fast **review-and-correct** flow: confirm/edit values, fix the *mapping* when the parser guessed wrong, and save that correction as a reusable per-client rule so the next file needs less review.

The deliverable to build is a **full-fledged web application** implementing this pipeline plus the review UX prototyped here.

## About the Design Files
The files in this bundle are **design references created in HTML** (a streaming "Design Component" prototype + a self-contained shareable copy). They demonstrate intended look and behavior — **they are not production code to copy**. Recreate the UI in the target codebase's environment (React/Vue/etc.) using its established component library, state, and styling patterns. If no frontend exists yet, React + TypeScript is a reasonable default. All extraction/OCR/AI logic in the prototype is **faked with canned data** — the real app must implement it server-side (see Architecture).

## Fidelity
**High-fidelity** for the review/confirmation UI: colors, typography, spacing, states, copy, and interactions are final and should be recreated faithfully. The surrounding app shell (the existing transactions table the user selects a row from) is **out of scope of the mock** — this feature opens once a single transaction is selected.

---

## Architecture (full app)

```
Client file  ──►  Ingestion  ──►  Format detection  ──►  Extraction  ──►  Mapping  ──►  Review UI  ──►  Validate  ──►  Submit/Book
(email, csv,      (upload,        (mime/sniff +          (per-format      (source→        (this           (control-sum,   (post to core
 xml, pdf,         inbox,          client profile)        parser / OCR /   target field    prototype)      BIC/IBAN, req    booking system,
 scan)             API)                                   LLM)             per profile)                     fields)          audit log)
```

### 1. Ingestion
- Accept uploads and/or a monitored mailbox/SFTP/API drop. Store the raw file immutably (this becomes the "Support Document" auto-attached in the form).
- Persist: `intake_id`, `client_id`, original filename, mime, received timestamp, raw bytes/URI.

### 2. Format detection
- Detect by mime + content sniffing (email headers, CSV delimiters, XML root, PDF magic bytes, image).
- Look up the **client mapping profile** (see Mapping) to pick the right parser/rules.

### 3. Extraction (the "AI or pandas/regex" layer)
Per format, produce a normalized list of **detected fields**: `{ sourceKey, label, rawValue, boundingBox?, ocrConfidence? }`.
- **CSV**: header→value mapping; handle European vs US number/date formats.
- **XML (incl. proprietary variants)**: XPath/element extraction driven by profile.
- **Email/plain text**: regex + labeled-line parsing, or an LLM extraction pass for free-form bodies.
- **PDF (text layer)**: text extraction + regex/LLM.
- **PDF/image (scanned)**: OCR (e.g. Textract/Tesseract/GCV) → tokens **with bounding boxes** and per-field OCR confidence. Bounding boxes power the "trace to region" highlight.
- Recommended hybrid: deterministic parsers first, LLM fallback/normalization for messy inputs. Always return a **confidence score (0–1)** and the **source provenance** (which bytes/box the value came from) per field — the UI depends on both.

### 4. Mapping (source → target form fields) + client profiles
- Target schema = the entry form fields (see Data Model).
- A **mapping profile** per `client_id` stores: source-field → target-field bindings, value transforms (number format, date format), and value aliases (e.g. `"audit accrual fee" → "Audit Fee ACCRL"`, account alias `"JPCH-BNK-HSMF"`, `"Mgmt Fee" → "Management Fee"`).
- Applying a profile raises confidence and reduces flags. When a user fixes a mapping in review and opts to save, **append/update the profile** so future files auto-apply it.
- Profiles are versioned and auditable.

### 5. Review UI
The prototype. Presents source (left) + mapped form (right), flags low-confidence/missing/required fields, supports edit, accept, fix-mapping, and three-way trace highlighting. Details below.

### 6. Validation (before submit)
- Required fields present (e.g. Reason when a support doc is attached).
- Domain checks: control-sum reconciliation for multi-line transactions, BIC/IBAN format & checksum, account exists, currency valid, value date ≥ trade date.
- Block or warn per rule severity.

### 7. Submit / Book
- On submit: persist the final entry, link the raw source doc, record which values were AI-filled vs user-edited and which mapping rules were applied (audit trail), then post to the downstream booking/core system. Return a booking reference (prototype shows `BKG-2026-00NN`).

---

## Data Model

### Target entry (form) fields
Grouped as in the form (section → fields). `kind` drives the control.

**Main**
| key | label | kind | notes |
|---|---|---|---|
| `group` | Group | select | options: Cash Management, FX Settlement, Collateral, Securities |
| `tradeDate` | Trade Date | date | |
| `valueDate` | Value Date | date | can be missing → required flag |
| `currency` | Currency | select | USD, EUR, GBP, JPY |
| `amount` | Amount | text/number | normalize decimal/thousands separators |
| `type` | Type | select | Audit Fee ACCRL, Management Fee, Custody Fee, Accrual — Other · **mappable** |
| `bu` | Business Unit | select | Hedge Start Master, Global Macro Fund, Rates Relative Value |
| `account` | Account | select | JPCH-BNK-HSMF, DBFR-BNK-GMF, BOEUK-BNK-RRV · **mappable** |
| `acctNumber` | Account Number | disabled | derived from account |

**Payment Model** — `paymentModel` (select: 10024 Test Error, 20015 Prod)
**Support Document** — `uploadFile` (auto-attached raw source), `reason` (select; required)
**Accounting** — `subAccount` (CASH, MARGIN, COLLATERAL), `positionBlock`, `refInstrument`

> The real option lists come from reference data services, not hardcoded.

### Field extraction record
```ts
type DetectedField = {
  sourceKey: string;      // stable key mapping to a target field
  label: string;          // as it appeared in the source
  rawValue: string;
  mappedValue: string;    // after transform/alias
  targetKey: string;      // e.g. "amount"
  confidence: number;     // 0..1
  level: 'high' | 'review' | 'required' | 'missing';
  note?: string;          // human explanation of the guess
  provenance?: { docId: string; box?: [x,y,w,h]; textSpan?: [start,end] };
  mappable?: boolean;     // can the user remap the rule?
};
```

### Multi-line note
A single transaction may contain **sub-transactions** (e.g. a multi-credit message): common/header fields + N line items sharing them, reconciled by a control sum. The current prototype (Create New Entry) models a single entry; the earlier explorations in this project show the sub-transaction card/table/accordion patterns if that path is needed.

---

## Screens / Views

### 1. Review (primary)
**Purpose:** verify and correct the auto-filled entry for one selected transaction, then submit.

**Layout:** modal/panel, `1160px` max width, white card, `border:1px solid #d3dad5`, `border-radius:12px`, `box-shadow:0 18px 50px rgba(15,50,38,.2)`.
- **Header row** (`padding:16px 22px`, bottom border `#e6eae6`): left = NT logo mark (28px rounded square `#115740`, white serif "NT") + title **"Create New Entry"** (`600 17px`, `#1a2420`); right = actions: **CANCEL** (ghost text `#6b7570`), **SAVE DRAFT** (outlined, save icon), **SUBMIT ▼** (green `#2f9e44`, hover `#268139`).
- **Intake-queue switcher** (`padding:12px 22px`, bg `#f7f9f7`): a label "Intake queue" + one tab per queued client file. Tabs are `flex:1 1 0; min-width:0` with the filename truncating (`text-overflow:ellipsis`); row is `overflow-x:auto`. Active tab: border `#115740`, bg `#eef4f1`, text `#115740`. Each tab shows a status dot (green=ready, amber=has flags), client name, filename, and a badge ("N to review" / "Ready").
- **Review banner** (`padding:10px 22px`, bg `#f2f8f4`, bottom border `#dbe8e1`): "Prefilled from `<file>`" + review count ("N fields need review before submit", amber `#8a5a12`; when 0, green "All fields verified — ready to submit") + a legend (High `#0f5b41`, Review `#8a5a12`, Required `#a3271c`).
- **Body grid** `grid-template-columns: 410px 1fr`:
  - **Left — Source panel** (`bg #fbfcfb`, right border): header ("Source · `<kind>`" + "click a field to trace →"). Contains:
    - **Raw file** box `#raw-scroll` (scrollable, `max-height:150px`). Renders the file as monospace lines; extracted **value tokens are clickable spans** (`data-rkey`) styled green `#12604a` with teal highlight (`#cfe9ec` bg + `#6bbcc4` outline) when traced.
    - For **scanned/OCR** sources: a badge "Scanned PDF · OCR extracted — verify the boxed regions"; the box gets a paper look (`bg #f4f2ea`, faint scanline gradient, courier font, `max-height:250px`) and each token renders as a **dashed bounding-box** (`1px dashed #b6a870`, semi-transparent fill) turning teal when traced. In production these boxes should be positioned over the actual page image using OCR bounding-box coordinates.
    - **Detected fields** list `#detected-scroll` (scrollable): label + value rows (`data-pkey`), highlight teal when traced.
  - **Right — Form** `#form-scroll` (scrollable, `max-height:640px`, bg `#fdfefd`, `padding:16px 20px`): the grouped sections. Non-header first section (main), then collapsible sections (Payment Model, Support Document, Accounting) with green section titles (`600 13px #115740`) and a ⌃/⌄ caret.
    - **Field row**: `grid 150px 1fr`, label left (`500 12.5px #3a453f`), control right. Control widths: selects 300px, dates/amount 200px, account number 130px. Inputs/selects: `border:1px solid #cfd4d1`, `border-radius:4px`, `padding:8px 10px`. Disabled fields: bg `#f1f4f2`, text `#8a938c`. Amounts/codes use IBM Plex Mono.
    - **Flagged row**: left accent bar `3px` (amber `#d99a2b` review / red `#cf4a3c` required), tinted bg (`#fffdf6` / `#fffafa`), input border amber `#ecd9ac`. Shows a **chip** (Review · NN% / Required), a **note** explaining the guess, an **✓ Accept** button (`#115740`), and for mappable fields a **"Fix mapping ▾"** toggle.
    - **Fix-mapping popover**: prompt + a select of candidate mappings + a checkbox "Save to `<client>` profile" + "Apply & save rule" button. Applying resolves the field and fires a toast "Mapping rule saved to `<client>` profile".
    - **Traced row**: teal outline `2px solid #6bbcc4`.
    - **Sticky scroll cues** inside the form: a sticky **top bar** ("N fields above need review") and **bottom bar** ("Scroll down to review N fields"), shown only when flagged fields are outside the viewport; clicking jumps (smooth scroll) to the nearest out-of-view flagged field. Bar style: bg `#fff6e9`, border `#eccf95`, text `#8a5a12`.

### 2. Confirmation
**Purpose:** confirm submission and surface saved learning.
- Green check circle, "Entry submitted for booking", reference `BKG-2026-00NN`, client + source file.
- **Booked entry** summary table (label→value for the key fields).
- **"Mapping rules saved to `<client>` profile"** card listing the rules learned this session, with a line: "Next file from this client auto-applies these — fewer fields to review."
- Actions: "Back to entry", "Review next in queue →" (loads next file).

---

## Interactions & Behavior
- **Three-way trace highlight:** clicking a raw-file token, a detected-field row, or a form field highlights all three correlated elements (teal). Implemented via a single `traced` key that all three read.
- **Scroll-into-view:** on trace, each scroll container (raw, detected, form) smoothly scrolls the correlated element into view if off-screen (`scrollTo({ top, behavior:'smooth' })`, centered). **Trigger the scroll from the click handler**, not a post-render lifecycle hook (the latter proved unreliable).
- **Edit:** all controls are live-editable (selects/inputs). Editing a flagged field should let the user resolve it.
- **Accept:** clears the flag, marks the field confirmed (green), decrements the review count and banner.
- **Fix mapping:** resolves the field, optionally writes the rule to the client profile, shows a toast (~2.6s).
- **Doc switching:** selecting a queue tab loads that file's source + values + flags and resets form scroll to top.
- **Submit:** validates, moves to Confirmation, generates a reference.
- **Section collapse:** header toggles section body.
- **Toast:** transient bottom-centered confirmation.

## State Management
Mirror the prototype's model:
- `docId` (current file), `screen` ('review' | 'confirm'), `values` (per-doc edited field values, overlaying extracted defaults), `resolved` (per-doc accepted flags), `mapOpen` (which fix-mapping popover is open), `traced` (correlated highlight key), `open` (collapsed sections), `toast`, `refNo`.
- Derived: current doc, active-flag count (a flag is active if the field is flagged AND not resolved AND — for required — still empty/placeholder), doc tabs, section field view-models, source raw/parsed view-models.
- In production, back `values`/`resolved`/mapping edits with API calls; the extracted fields, confidence, and provenance come from the extraction service.

## Design Tokens
- **Brand green (Northern Trust):** primary `#115740`, hover/dark `#0c3e2d`, deep header `#0f4636`.
- **Submit green:** `#2f9e44`, hover `#268139`.
- **Confidence:** high text `#0f5b41` / chip bg `#e6f2ec` border `#bfe0cf`; review text `#8a5a12` / bg `#fbefd9` border `#eccf95` / accent `#d99a2b`; required text `#a3271c` / bg `#fdeceb` border `#f5cfcc` / accent `#cf4a3c`.
- **Trace highlight:** bg `#cfe9ec`, outline `#6bbcc4`.
- **Neutrals:** page bg `#e9ede9`; card `#fff`; panel `#fbfcfb`/`#fdfefd`; borders `#e6eae6`/`#e2e6e3`/`#cfd4d1`; ink `#1a2420`; label `#3a453f`; muted `#5f6b64`/`#8a938c`/`#a7b0a9`.
- **Scan paper:** bg `#f4f2ea`, border `#d8d4c4`, box `1px dashed #b6a870`.
- **Type:** UI = **IBM Plex Sans** (400/500/600/700); codes/amounts/monospace source = **IBM Plex Mono**; scanned facsimile = Courier New. Logo mark = Georgia serif.
- **Radius:** cards 12px, sections 8px, controls 4–6px, chips 20px. **Shadow (card):** `0 18px 50px rgba(15,50,38,.2)`.

## Assets
- No raster assets. Icons are inline SVGs (save/floppy, calendar, paperclip, check, scan). NT logo is a text mark ("NT") — replace with the official Northern Trust logo asset in production and follow NT brand guidelines. Fonts load from Google Fonts (IBM Plex Sans/Mono); self-host in production.

## Suggested implementation phases
1. **Data model + reference data** for the entry form and option lists.
2. **Ingestion + storage** of raw files; format detection.
3. **Extraction services** per format (start CSV/XML/email deterministic; add PDF text; add OCR for scans; add LLM fallback). Emit confidence + provenance.
4. **Mapping profiles** store + apply + learn-on-save.
5. **Review UI** (recreate this prototype) wired to extraction + mapping APIs.
6. **Validation rules** engine (required, control-sum, BIC/IBAN, dates).
7. **Submit/booking integration + audit trail.**
8. Metrics: time-to-book, fields auto-accepted vs edited, per-client review rate over time.

## Screens (reference captures)
In `screens/`:
1. `01-review-email.png` — Review screen, email source (Arden Capital). Default state: intake-queue tabs, review banner, source panel (raw + detected), grouped form.
2. `02-trace-highlight.png` — Three-way trace: a detected/source field and its form field highlighted teal together.
3. `03-fix-mapping.png` — "Fix mapping" popover open: candidate mappings + "save to client profile" + Apply.
4. `04-review-csv.png` — CSV source (Meridian FX); note European decimal amount flagged.
5. `05-review-xml.png` — Proprietary XML source (Brightwater); missing value date → required flag.
6. `06-review-scan-ocr.png` — Scanned PDF (Castlepoint): OCR badge, paper facsimile, dashed bounding-box regions, lower confidence / more flags.
7. `07-sticky-scroll-cue.png` — Sticky "fields above/below need review" cue when flags are off-screen.
8. `08-confirmation.png` — Confirmation: booked-entry summary, saved mapping rules, "Review next in queue".

## Files
- `SWIFT Extraction Review.dc.html` — the interactive prototype (source of truth for UI/interactions). Note: authored as a streaming "Design Component"; treat as a visual/behavioral reference, not a build target.
- `SWIFT Extraction Review — shareable.html` — self-contained single-file copy (open in any browser, no network) to click through the flows.
- `screens/` — annotated state captures (see above).
